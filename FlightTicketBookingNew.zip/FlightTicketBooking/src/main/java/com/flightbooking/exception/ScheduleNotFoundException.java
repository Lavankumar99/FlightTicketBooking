package com.flightbooking.exception;

public class ScheduleNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ScheduleNotFoundException() {
		super();

	}
}
