package com.flightbooking.exception;

public class BookingNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public BookingNotFoundException() {
		super();

	}
}
