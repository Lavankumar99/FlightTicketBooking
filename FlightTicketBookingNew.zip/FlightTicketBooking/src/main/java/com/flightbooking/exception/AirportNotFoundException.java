package com.flightbooking.exception;

public class AirportNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AirportNotFoundException() {
		super();

	}

}
